![EMILIA](https://c.top4top.io/p_2109b2vnx0.gif) <br>

<p align="center">
<a href="https://t.me/CyzChan" alt="Telegram!"> <img src="https://aleen42.github.io/badges/src/telegram.svg" /> </a>
<a href="https://wa.me/6285329981485" alt="WhatsApp!"> <img src="https://aleen42.github.io/badges/src/whatsapp.svg" /> </a>
<a href="https://github.com/Kotzyy/Emilia-Bot/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-green.svg" /> </a>
</p>
<p align="center">
<a href="https://github.com/Kotzyy/Emilia-Bot" alt="Clossed Issue"> <img src="https://img.shields.io/github/issues-closed-raw/Kotzyy/Emilia-Bot?style=flat&logo=github&color=success" /> </a>
<a href="https://github.com/Kotzyy/Emilia-Bot" alt="Commit Activity"> <img src="https://img.shields.io/github/commit-activity/m/Kotzyy/Emilia-Bot" /> </a>
<a href="https://github.com/Kotzyy/Emilia-Bot/graphs/contributors" alt="Contributor"> <img src="https://img.shields.io/github/contributors/Kotzyy/Emilia-Bot?style=flat&logo=github" /> </a>
<a href="https://github.com/Kotzyy/Emilia-Bot/network/members" alt="Forks"> <img src="https://img.shields.io/github/forks/Kotzyy/Emilia-Bot?label=Forks&logo=github" /> </a>
<a href="https://github.com/Kotzyy/Emilia-Bot" alt="Clossed Pull Request"> <img src="https://img.shields.io/github/issues-pr-closed-raw/Kotzyy/Emilia-Bot?color=success" /> </a>
<a href="https://github.com/Kotzyy/Emilia-Bot" alt="Issue"> <img src="https://img.shields.io/github/issues-raw/Kotzyy/Emilia-Bot?style=flat&logo=github&color=yellow" /> </a>
</p>
</div>

# Emilia Bot Wea
Emilia Bot Wea actually I made just for personal use, but if you want to use it, go ahead, but don't forget to STAR :)


>
>
>
</div>
<p align="center">
  <a href="https://github.com/Kotzyy"><img title="Author" src="https://img.shields.io/badge/Author-Kotz-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
</h4>
</p>

# Requirements
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip) (for sticker command)
* [Libwebp](https://developers.google.com/speed/webp/download) (for sticker wm)
* Any text editor

# Instalasi
## For Windows
```bash
git clone https://github.com/Kotzyy/Emilia-Bot.git
cd Emilia-Bot
npm install
```
## For Termux
```bash
apt update && apt upgrade
pkg install nodejs git ffmpeg libwebp
git clone https://github.com/Kotzyy/Emilia-Bot.git
cd Emilia-Bot
npm install
```

## For VPS
```bash
apt install nodejs git ffmpeg libwebp
git clone https://github.com/Kotzyy/Emilia-Bot.git
cd Emilia-Bot
npm install
```
# Run bot
```cmd
node .
```

## Require

Edit the ./setting.json file first, if you don't understand then leave it as it is
```json
{
     "multi": true,
     "prefix": "#",
     "antidelete": false,
     "autocomposing": true,
     "autorecording": false,
     "autoread": true,
     "banChats": true,
     "antiSpam": true,
     "ownerName": "Kotz",
     "owner": "628xxxxxxxx",
     "apikey": "ISI_APIKEYMU",
     "gamewaktu": 60,
     "Donasi": "https://saweria.co/kotzxemilia\nTerima Kasih Yang Udh Donasi Emilia Doain Semoga Rezekinya Lancar ><"
}
```

## Credit 📍
* Well, it's all in the commit history, feel free to open a pull request if you find any errors/bugs
* And don't forget to leave a STAR ok
* And wait for my next update!!👣
* I hope the masters are quiet first, I know you are great, so I hope you can respect me

## Apikey

- [Ogata-Api's](https://ogata-api.herokuapp.com/)<div align="center">


## License
[MIT](https://choosealicense.com/licenses/mit/)
Copyright © 2020-present

## Big Thanks To

- [Baileys](https://github.com/adiwajshing/Baileys)
- [Nino](https://github.com/ultimareall)
- [Kotz](https://github.com/Kotzyy)<div align="center">
