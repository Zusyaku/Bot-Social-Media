module.exports.mess = {
	        wait: 'Harap tunggu sebentar',
			success: 'Ok Sudah kak~ ',
			wrongFormat: 'Maaf kak formatnya salah. Pastikan sudah benar dengan data di ${prefix}menu',
			blocked: 'Maaf Emilia tidak bisa menerima telepon kak. Karena kamu telah melanggar rules, maka kamu telah diblok!\n\nHarap hubungi owner: wa.me/6285329981485',
			error: {
				api: 'Ehhh, Terjadi Kesalahan Silahkan Hubungi Owner Emilia',
				stick: 'Menurut Emilia Itu Bukan Sticker',
				Iv: 'Menurut Emilia Itu Bukan Sticker'
			},
			only: {
				group: 'Command ini hanya bisa digunakan di dalam grup!',
				admin: 'Command ini hanya bisa digunakan oleh admin grup!',
				premium: 'Kamu bukan user premium, kirim perintah *!buypremium* untuk membeli premium',
				owner: 'Command ini khusus Owner-Emilia',
				Badmin: 'Emilia bukan admin kak:(',
			}
		}