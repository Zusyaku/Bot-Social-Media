const txt = 'Hello world!'
for (let i = 0; i < txt.length; i++) {
    console.log(txt.charAt(i))
}
