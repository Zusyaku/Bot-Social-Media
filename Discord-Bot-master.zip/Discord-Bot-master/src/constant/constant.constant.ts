export interface MsgSerialize {
    msg_id?: string
    msg_from?: string
    msg_text?: string
    args?: string[]
    command?: string
    author_avatar?: string
}
