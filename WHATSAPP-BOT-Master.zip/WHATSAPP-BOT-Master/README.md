

## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px"> Hai stah > 👑 

## نُسَارِعُ لَهُمْ فِي الْخَيْرَاتِ ۚ بَلْ لَا يَشْعُرُونَ

## Kami bersegera memberikan kebaikan-kebaikan kepada mereka? Tidak, sebenarnya mereka tidak sadar {1008}.

## Q.S Al Mu'minun ayat 56

<p align="center">

<img src="https://i.postimg.cc/HWFsQyRv/rizki.jpg" width="230" height="230"/>

</p>



<p align="center">

<img src="https://img.shields.io/badge/-JavaScript-black?style=flat-square&logo=javascript" />

  <img src="https://img.shields.io/badge/-Node.js-black?style=flat-square&logo=Node.js" />


### Support me
- [Saweria](https://saweria.co/RR018)


