[![Welcome to Amal-dx Repo](https://readme-typing-svg.herokuapp.com?color=%231ABDF7&lines=WELCOME+TO+AMAL-DX+REPO)](https://git.io/typing-svg)
## 📢Introduce myself

- 🙂I'm Amal
- 🚩I'm a beginner in this field
- 📍From pathripala,palakkad,Kerala,🇮🇳
- 🏫Students

<div align="center">
  <img src=http://telegra.ph/file/68809ff84d7cd4447a76e.jpg>
 


# **DXTROX-V2 whatsapp bot**

##  [![NodeJs](https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white)](https://nodejs.org/en/)

  Click 👇 here to join our whatsapp group
[![join](https://github.com/Alien-alfa/PublicBot/blob/main/wlogo.svg.png)](https://chat.whatsapp.com/ByLfu3PoWJA7YavsaTi7wx)
  <div align="center">


## 🎗 Heroku deploying
 
 #### **deploying on Heroku**

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/amal-dx/DXTROX-v2)

### 📌 Heroku deploying Guide
- Click Here > [heroku-Guide](https://github.com/amal-dx/heroku-guide/blob/main/README.md)
 
 ## 🍀 Installation
 
 
 ```js 
 > update && apt upgrade
 > apt install git -y
 > apt install nodejs -y
 > apt install ffmpeg -y
 > apt install imagemagick -y
 > git clone  https://github.com/amal-dx/DXTROX-v2
 > cd DXTROX-v2
 > npm install 
 > node . [session-name] 
 ```
 ##  🌝 **Contribution**
 
 - As you know there are lots of missing files in /plugins and If you want to contribute please consider Doing PRs thank you
 
 
 ##  Developer
 👤  **Amal-dx**
* WhatsApp : https://wa.me/917736308760



## 📝 License 

+ This project is [MIT License v3.0](https://github.com/amal-dx/DXTROX-v2/blob/main/LICENSE) licensed. 



## Show your support 

Give a ⭐️ if this project helped you!








*THANKS TO NURUTOMO AND Eru and ALL DEVELOPERS*
 
