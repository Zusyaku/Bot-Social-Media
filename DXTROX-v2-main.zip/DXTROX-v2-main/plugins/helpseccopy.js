/*
   Coded by amal-dx
*/
// let handler = async m => m.reply(`
// General 🌈 this only test okay?

// 💠 CMD: #help
// ♦ Description: Shows the command lists based on the index
// 🔰 Usage: #help (number)
// ❄ Example: #help 1

// 💠 CMD: #group
// ♦ Description: Displayes the groupinfo
// 🔰 Usage: #group


// 💠 CMD: #report
// ♦ Description: Report any bug
// 🔰 Usage: #report [text]
// ❄ Example: #report Wallpaper isn't working

// 💠 CMD: #info
// ♦ Description: Well...
// 🔰 Usage: #info


// 💠 CMD: #support
// ♦ Description: Lists all the support group links
// 🔰 Usage: #support
// `.trim()) // Tambah sendiri kalo mau
// handler.help = ['help 1']
// handler.tags = ['info']
// handler.command = /^help 1$/i

// module.exports = handler
