/*
   Coded by amal-dx
*/
// let handler = m => m.reply('Waalaikumsalam')

// handler.customPrefix = /Assalammualaikum/i
// handler.command = new RegExp

// module.exports = handler

// let handler = m => m.reply('Did you mean help?')

// handler.customPrefix = /:/i
// handler.command = new RegExp

// module.exports = handler
