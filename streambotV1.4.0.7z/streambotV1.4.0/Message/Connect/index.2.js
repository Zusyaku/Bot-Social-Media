global.APIs = {
  bx: 'https://bx-hunter.herokuapp.com',
  dhnjing: 'https://dhnjing.xyz',
  kotzyy: 'https://api.kotzyy.xyz',
  hardianto: 'https://hardianto-chan.herokuapp.com',
  jonaz: 'https://jonaz-api-v2.herokuapp.com',
  neoxr: 'https://neoxr-api.herokuapp.com',
  nrtm: 'https://nurutomo.herokuapp.com',
  pencarikode: 'https://pencarikode.xyz',
  xteam: 'https://api.xteam.xyz',
  zahir: 'https://zahirr-web.herokuapp.com',
  zekais: 'http://zekais-api.herokuapp.com',
  zeks: 'https://api.zeks.xyz',
  DashBot: 'https://api.lolhuman.xyz', 
}

global.APIKeys = {
  'https://api.kotzyy.xyz': 'KotzKey',
  'https://bx-hunter.herokuapp.com': 'Ikyy69',
  'https://hardianto-chan.herokuapp.com': 'hardianto',
  'https://neoxr-api.herokuapp.com': 'yntkts',
  'https://pencarikode.xyz': 'pais',
  'https://api.xteam.xyz': 'apikeymu',
  'https://zahirr-web.herokuapp.com': 'zahirgans',
  'https://api.zeks.xyz': 'apivinz',
  'https://api.lolhuman.xyz': 'DashBot',
}

module.exports = { APIs, APIKeys } 

module.exports.userbot = userbot = {
 owner:  [ "6281261324817", "436505555868686", "6285934360746", "62895622934562" ],
   mess: {
   wait: "tunggu sedang di proses...",
   api: "Maaf terjadi kesalahan", 
   success: "Berhasil",
   SudahAktif: "Perintah Tersebut Sudah Diaktifkan Sebelumnya.",
   SudahNonaktif: "Perintah Tersebut Sudah Dinonaktifkan Sebelumnya.",
   KhususGrup: "Perintah ini hanya bisa digunakan di Grup",
   KhususPribadi: "Perintah ini hanya bisa digunakan di private message",
   GrupAdmin: "Perintah ini hanya bisa digunakan oleh Admin Grup",
   BotAdmin: "Bot Harus menjadi admin",
   FreeAdmin: "Admin Bebas",
   KhususOwner: "Perintah ini hanya dapat digunakan oleh owner bot",
   KhususPremium: "Perintah ini khusus member premium"
   },
   error: {
   Iv: "Link yang kamu berikan tidak valid",
   tombol: "Silahkam Masukkan prameter on/off",
   forget: "Silahkan Masukkan Teks Anda."
   },
   simple: {
   pilihan: "SILAHKAN PILIH SALAH SATU"
   }, 
   image: {
   undefined: 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg', 
   mmgmag: 'https://mmg.whatsapp.net/d/f/Ano5cGYOFQnC51uJaqGBWiCrSJH1aDCi8-YPQMMb1N1y.enc', 
   butmag1: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQinCt49zd8UYSmN_AZ_pFlj_Zza_SNqhaHzA&usqp=CAU',
   butmag2: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUh5i0W7GoK27gGgKNgXcryDwNidNO1ixUTw&usqp=CAU',
   butmag3: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHRWun54ErKLGHzBc7VtNoCvIMHwgaZkEWtQ&usqp=CAU',
   butmag4: 'https://i.ibb.co/7Y56B5L/images.png', 
   butmag5: 'https://i.ibb.co/HK3t3Xf/20211205-151134.jpg',
   butmag6: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQlZti2vv4DRos0VAmiryJvrHuIUnVJh6m25w&usqp=CAU', 
   butmag7: 'https://www.dexigner.com/images/directory/xxi/13786.jpg', 
   butmag8: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTHTRQ9hMI16BPYoMh9AoP1anRUp-IHnXxGg&usqp=CAU', 
   butmag9: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-4tD5Fgzj_qyvey5Yu8Y5rrUwQ_7fe91sLg&usqp=CAU', 
   butmag10: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNskS1ql7AjGQ3CRIn9kVYmv9k6e3K2d8QPg&usqp=CAU',
   butmag11: 'https://i.ibb.co/7Y56B5L/images.png', 
   butmag12: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXUV7VyhIVfkbokNT4-WrFCdvQD1Q4Z1_9JFjzc7EQS-Nm-qhcaepLxEU5&s=10', 
   getbuff1: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPgNAZVPinSTu3TJ6cpCj5MqrPAl_NAUNcag&usqp=CAU'
   }, 
   setting: {
   packname: "Stream-BOT",
   author: "Arifi Razzaq",
   prefix: ["/"],
   bio1: "Pejuang Sholawat", 
   bio2: "Road To 30 Juz", 
   gc1: "https://chat.whatsapp.com/C7Vg3OigpIr1oEdbY43E4b", 
 }
   }