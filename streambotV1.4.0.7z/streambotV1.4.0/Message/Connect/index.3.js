module.exports.menu = (prefix, l) => { 
return `─ ⌜ *Informasi Bot* ⌟ ─
${l++}. ${prefix}owner
${l++}. ${prefix}menu
${l++}. ${prefix}rules
${l++}. ${prefix}credits
${l++}. ${prefix}status
${l++}. ${prefix}uptime
${l++}. ${prefix}runtime
${l++}. ${prefix}speed

─ ⌜ *Khusus Owner* ⌟ ─
${l++}. ${prefix}delete
${l++}. ${prefix}kick

─ ⌜ *Pengguna Premium* ⌟ ─
${l++}. ${prefix}q

─ ⌜ *Hanya Dalam Grup* ⌟ ─
${l++}. ${prefix}listonline
${l++}. ${prefix}sider
${l++}. ${prefix}linkgrup

─ ⌜ *Kerang Ajaib* ⌟ ─
${l++}. ${prefix}truthdare

─ ⌜ *Sticker* ⌟ ─
${l++}. ${prefix}sticker
${l++}. ${prefix}swm nama|author
`
}

module.exports.rules = (prefix, l) => {
return `「 *𝗥𝗨𝗟𝗘𝗦 𝗕𝗔𝗚𝗜 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔 𝗕𝗢𝗧* 」
    
${l++}. Tolong Kasih Jeda Bot, Dan Jangan Spam Saat Menggunakan Bot.
${l++}. Call/VC Bot Auto Block.
${l++}. Kami tidak menyimpan gambar, video, file, audio, dan dokumen yang anda kirim
${l++}. Kami tidak akan pernah meminta anda untuk memberikan informasi pribadi
${l++}. Jika menemukan Bug/Error silahkan langsung lapor ke Owner bot
${l++}. Kalian juga bisa menbuat bot sendiri caranya liat yt owner Arifi Razzaq OFFICIAL
${l++}. Konsekuensi Bila Melanggar Rules, Bot Akan Memblokir Kamu Atau Mengeluarkan Kamu Dari Grup.
`
}

module.exports.credits = (gaya) => {
return `「 *𝗦𝗣𝗘𝗖𝗜𝗔𝗟 𝗧𝗛𝗔𝗡𝗞𝗦 𝗧𝗢* 」

${gaya} Arifi Razzaq | FXdeveloper | Devil Botz | Habibi Gz | RidhoGanz | NYX-Chan | Deff | Akira | Dhani Botz | KurrXd | Iqbal


「 *𝗧𝗛𝗔𝗡𝗞 𝗬𝗢𝗨 𝗖𝗢𝗠𝗣𝗔𝗡𝗬* 」
${gaya} Allah SWT | Orang Tua | All. Developer | Penyedia Apikey | HydraThrow Team | WhatsApp Web Api
`
}


//اتَّقوا النَّارَ ولو بشقِّ تمرةٍ ، فمن لم يجِدْ فبكلمةٍ طيِّبةٍ
//“jauhilah api neraka, walau hanya dengan bersedekah sebiji kurma (sedikit). Jika kamu tidak punya, maka bisa dengan kalimah thayyibah” [HR. Bukhari 6539, Muslim 1016 