# DGH BOT V3

- Made By Sintya

- Made on 12/5/2021
- All Cmd Working
- Copyright 2021
- Github: Sintya4
- Discord Name: @么Sintya#0001
- Discord ID: 740947753135243354
- Source Github: [DGH BOT V3](https://github.com/Sintya4/PREMIUM-DGH-BOT-V3)

- Bot Name: DGH BOT V3
- Dashboard: [Click](http://dghbot.ddns.net)
- Support My server 
- Link: http://dghbot.ddns.net/dc
- Owner: [👑] 么Sintya#0001
- [@Sintya4](http://github.com/Sintya4)

<a href="https://dblist.ddns.net/bots/849903077690572800">
<img src="https://dblist.ddns.net/api/embed/849903077690572800"/>
 </a>  

> # 💨 Run the projects

[![Remix on Glitch](https://cdn.glitch.com/2703baf2-b643-4da7-ab91-7ee2a2d00b5b%2Fremix-button.svg)](https://glitch.com/edit/#!/import/github/sintya4/PREMIUM-DGH-BOT-V3)<br>
[![Run on Repl.it](https://repl.it/badge/github/vcodes-xyz/bot-list)](https://repl.it/github/sintya4/PREMIUM-DGH-BOT-V3)<br>
[![Watching](https://img.shields.io/github/watchers/sintya4/PREMIUM-DGH-BOT-V3?style=for-the-badge)](/)
[![Stars](https://img.shields.io/github/stars/sintya4/PREMIUM-DGH-BOT-V3?style=for-the-badge)](https://github.com/Sintya4/PREMIUM-DGH-BOT-V3/stargazers)
[![Forks](https://img.shields.io/github/forks/Sintya4/PREMIUM-DGH-BOT-V3?style=for-the-badge)](https://github.com/Sintya4/PREMIUM-DGH-BOT-V3/network/members)
[![ISSUES](https://img.shields.io/github/issues-raw/sintya4/PREMIUM-DGH-BOT-V3?color=blue&logo=github&style=for-the-badge)](https://github.com/Sintya4/PREMIUM-DGH-BOT-V3/issues)

# Stargazers
[![Stargazers repo roster for @Sintya4/PREMIUM-DGH-BOT-V3](https://reporoster.com/stars/dark/notext/Sintya4/PREMIUM-DGH-BOT-V3)](https://github.com/Sintya4/PREMIUM-DGH-BOT-V3/stargazers)

# Forkers
[![Forkers repo roster for @Sintya4/PREMIUM-DGH-BOT-V3](https://reporoster.com/forks/dark/notext/Sintya4/PREMIUM-DGH-BOT-V3)](https://github.com/Sintya4/PREMIUM-DGH-BOT-V3/network/members)