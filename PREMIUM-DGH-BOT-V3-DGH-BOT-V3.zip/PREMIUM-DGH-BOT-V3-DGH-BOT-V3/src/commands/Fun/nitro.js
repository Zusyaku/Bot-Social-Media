module.exports = {
  name: "nitro",
  category: "fun",
  cooldown: 5000,
  run: async (client, message, args) => {
    message.channel.send("Free Nitro :D\nhttps://discord.gift/pnQQ9KxKuMqT2KNxHuKANhvc");
  }
};
