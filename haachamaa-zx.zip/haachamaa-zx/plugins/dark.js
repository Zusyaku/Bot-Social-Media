let handler = async (m) => {
  
let teks = `
┏ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇          *「 Rekomendasi Dari Saya 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Anime Jujutsu Kaisen 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/jujutsu-kaisen/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Jujutsu Kaisen 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/jujutsu-kaisen/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Anime Kimetsu no Yaiba 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/kimetsu-no-yaiba/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Movie Kimetsu no Yaiba : Mugen Ressha-Hen 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/kimetsu-no-yaiba-movie-mugen-ressha-hen/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Kimetsu no Yaiba」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/kimetsu-no-yaiba/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Kimetsu no Yaiba : Giyuu Gaiden 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/kimetsu-no-yaiba-tomioka-giyuu-gaiden/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Kimetsu no Yaiba : Rengoku Gaiden 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/kimetsu-no-yaiba-rengoku-kyoujurou-gaiden/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Kimetsu no Yaiba : Yushirou Epilogue 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/kimetsu-no-yaiba-yushirou-epilogue/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Kimetsu no Yaiba : Zenitsu and Nezuko Afterstory 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/kimetsu-no-yaiba-zenitsu-and-nezukos-afterstory/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Kimetsu no Yaiba : Tanjiro Proposes 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/kimetsu-no-yaiba-x-years-later-tanjiro-proposes/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Anime Kumo Desu ga, Nani ka?」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/kumo-desu-ga-nani-ka/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Kumo Desu ga, Nani ka? 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/kumo-desu-ga-nani-ka/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Kumo Desu ga, Nani ka? Daily Life of  The Four Spider Sisters」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/kumo-desu-ga-nani-ka-daily-life-of-the-four-spider-sisters/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Novel Kumo Desu ga, Nani ka? 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://www.luinovel.xyz/2020/04/im-spider-so-what-bahasa-indonesia-download.html?m=1
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Anime Mushoku Tensei : Isekai Ittara Honki Dasu 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/mushoku-tensei-isekai-ittara-honki-dasu/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Mushoku Tensei : Isekai Ittara Honki Dasu 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/mushoku-tensei-isekai-ittara-honki-dasu/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga Mushoku Tensei :  Roxy is Serious」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/mushoku-tensei-roxy-is-serious/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Novel Mushoku Tensei : Isekai Ittara Honki Dasu 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://www.baka-tsuki.org/project/index.php?title=Mushoku_Tensei_(Indonesia)
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Anime One Punch Man Season I 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/one-punch-man-sub-indonesia-qo636/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Anime One Punch Man Special 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/one-punch-man-specials/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Anime One Punch Man Season II 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/one-punch-man-2nd-season/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga One Punch Man 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/?s=one+punch+man
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Manga One Punch Man One 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://komikindo.co/manga/onepunch-man-one/
┗ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
`.trim()
  conn.fakeReply(m.chat, teks, '0@s.whatsapp.net', 'Link Anime Recomend', 'status@broadcast')
  }
handler.command = /^dark$/i
handler.register = true
handler.group = false
handler.private = false
handler.limit = true

module.exports = handler
