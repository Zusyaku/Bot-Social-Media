const { MessageType } = require('@adiwajshing/baileys')
const { sticker } = require('../lib/sticker')
let handler  = async (m, { conn, args }) => {
  let stiker = false
  await m.reply(global.wait)
  try {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    if (/image|video/.test(mime)) {
      let img = await q.download()
      if (!img) throw 'Foto/Video tidak ditemukan'
      stiker = await sticker(img, false, 'Haachamaaaa', 'aaaaaaaa')
    } else if (args[0]) stiker = await sticker(false, args[0], 'Haachamaaaa', 'aaaaaaaa')
  } finally {
    if (stiker) conn.sendMessage(m.chat, stiker, MessageType.sticker, {
      quoted: m
    })
    else throw 'Conversion failed'
  }
}

handler.command = /^s(tic?ker)?(gif)?$/i
handler.limit = true
handler.register = true
module.exports = handler
