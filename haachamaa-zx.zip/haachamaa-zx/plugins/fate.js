let handler = async (m) => {
  
let violet =  './src/photo/VioEver.png'
let teks = `
┏ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇          *「 Fate Series 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Zero 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-zero/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Zero : Onegai Einzbern Soudanshitsu (Special) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-zero-onegai-einzbern-soudanshitsu/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Grand Order : First Order (Special) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-grand-order-first-order/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Grand Order : Zettai Majuu Sensen Babylonia (Movie) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-grand-order-zettai-majuu-sensen-babylonia-gcbqj/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Grand Order : Shinsei Entaku Ryouiki Camelot 1 (Movie) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-grand-order-shinsei-entaku-ryouiki-camelot-1-wandering-agateram/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Stay Night 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-stay-night/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Stay Night : Unlimited Blade Works 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-stay-night-unlimited-blade-works-sub-indo/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Stay Night : Unlimited Blade Works Season II  」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-stay-night-unlimited-blade-works-2nd-season/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Stay Night : Unlimited Blade Works Season II (Special) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-stay-night-unlimited-blade-works-2nd-season-sunny-day/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Stay Night : Unlimited Blade Works (Movie) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-stay-night-movie-unlimited-blade-works/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Stay Night : Heavens Feel I Presage Flower (Movie) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-stay-night-movie-heavens-feel-i-presage-flower/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Stay Night : Heavens Feel II Lost Butterfly (Movie) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-stay-night-movie-heavens-feel-ii-lost-butterfly/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Stay Night : Heavens Feel III Spring Song (Movie) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-stay-night-movie-heavens-feel-iii-spring-song/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Apocrypha 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-apocrypha/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Kaleid Liner Prisma Ilya 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-kaleid-liner-prisma☆illya/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Kaleid Liner Prisma Ilya 2Wei Herz 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-kaleid-liner-prisma☆illya-2wei/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Kaleid Liner Prisma Ilya 2Wei 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-kaleid-liner-prisma☆illya-2wei/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Kaleid Liner Prisma Ilya 3Rei 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-kaleid-liner-prisma☆illya-3rei/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Kaleid Liner Prisma Ilya Prisma : Phantasm (Movie) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-kaleid-liner-prisma☆illya-prisma☆phantasm/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Kaleid Liner Prisma Ilya : Sekka no Chikai (Movie) 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-kaleid-liner-prisma-illya-movie-sekka-no-chikai/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Kaleid Liner Prisma Ilya 3Rei Special 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-kaleid-liner-prisma☆illya-3rei-specials/
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇ *「 Fate Extra : Last Encore 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ https://gomunime.online/anime/fate-extra-last-encore/
┗ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
`.trim()
  conn.fakeReply(m.chat, teks, '0@s.whatsapp.net', 'ABOUT FATE', 'status@broadcast')
  }
handler.command = /^fate$/i
handler.register = true
handler.group = false
handler.private = false
handler.limit = true

module.exports = handler
