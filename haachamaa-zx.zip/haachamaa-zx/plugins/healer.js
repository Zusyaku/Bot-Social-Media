let handler = async m => m.reply(`
┏ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇          *「 Link Anime Redo of Healer」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇                  *「 Kualitas 720 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ Eps 1 https://www52.zippyshare.com/v/uSoTF46o/file.html
┃ ~ Eps 2 https://www16.zippyshare.com/v/pAH0VIKg/file.html
┃ ~ Eps 3 https://www105.zippyshare.com/v/MFW8Jw0Z/file.html
┃ ~ Eps 4 https://www49.zippyshare.com/v/Ty5t9HXo/file.html
┃ ~ Eps 5 https://www102.zippyshare.com/v/aCzU8FoD/file.html
┃ ~ Eps 6 https://www85.zippyshare.com/v/YYXx97N2/file.html
┃ ~ Eps 7 https://www24.zippyshare.com/v/LQmAUkb4/file.html
┃ ~ Eps 8 https://www64.zippyshare.com/v/C1JnrgSp/file.html
┃ ~ Eps 9 https://www42.zippyshare.com/v/9ucTOuAK/file.html
┃ ~ Eps 10 https://www73.zippyshare.com/v/bAFEPxp1/file.html
┃ ~ Eps 11 https://www87.zippyshare.com/v/LoITv7Gv/file.html
┃ ~ Eps 12 https://www4.zippyshare.com/v/WJt1Mpm1/file.html
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇                  *「 Kualitas 1080 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃ ~ Eps 1 https://www94.zippyshare.com/v/RoRjo24B/file.html
┃ ~ Eps 2 https://www59.zippyshare.com/v/k4edbRmA/file.html
┃ ~ Eps 3 https://www10.zippyshare.com/v/dsfGkMOc/file.html
┃ ~ Eps 4 https://www9.zippyshare.com/v/Ho2E4NHV/file.html
┃ ~ Eps 5 https://www16.zippyshare.com/v/MQtRQmwR/file.html
┃ ~ Eps 6 https://www72.zippyshare.com/v/OXaNbm1i/file.html
┃ ~ Eps 7 https://www6.zippyshare.com/v/Uve1LbYB/file.html
┃ ~ Eps 8 https://www111.zippyshare.com/v/KZpLOnWh/file.html
┃ ~ Eps 9 https://www4.zippyshare.com/v/n7hPU3ul/file.html
┃ ~ Eps 10 https://www46.zippyshare.com/v/MrS0Zqo9/file.html
┃ ~ Eps 11 https://www14.zippyshare.com/v/JdxgBVEE/file.html
┃ ~ Eps 12 https://www104.zippyshare.com/v/r4JmnFOs/file.html
┗ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
`.trim()) // Tambah sendiri kalo mau
handler.command = /^healer$/i
handler.register = true
handler.group = true
handler.private = false
handler.limit = false
handler.premium = true

module.exports = handler