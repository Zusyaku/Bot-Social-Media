let handler = async (m) => {
  
let teks = `
┏ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇          *「 Link Anime Movie 」*
┣ ┅ ━━━━━━━━━━━
┃    *Kualitas 480 Tertera*
┃    *Kualitas 720 Tertera*
┃    *Kualitas 1080 Tertera*
┣ ┅ ━━━━━━━━━━━
┇         *「Violet Evergarden : The Movie 」*
┣ ┅ ━━━━━━━━━━━
┃         Kualitas 480
┃ ~ https://www.mp4upload.com/hjbxis14z3q9
┃          Kualitas 720
┃ ~ https://www.mp4upload.com/4c75b84c8oks
┣ ┅ ━━━━━━━━━━━
┇ *「 Demon Slayer The Movie : Mugen Ressha-Hen 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/81ffkmkcq0lm
┃          Kualitas 720
┃ ~ https://uptobox.com/b5i1eeg83odn
┃          Kualitas 1080
┃ ~ https://uptobox.com/a389ej9tc2ve
┣ ┅ ━━━━━━━━━━━
┇   *「 Koe no Katachi 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/alyiqro9urni
┃          Kualitas 720
┃ ~ https://uptobox.com/psa58v1zby9t
┃          Kualitas 1080
┃ ~ https://uptobox.com/di6923f37jjc
┣ ┅ ━━━━━━━━━━━
┇   *「 Kimi no Na Wa 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/8lg6fa3tqsf8
┃          Kualitas 720
┃ ~ https://uptobox.com/lg4wgm6i1ftl
┃          Kualitas 1080
┃ ~ https://uptobox.com/4g4far8u5zzn
┣ ┅ ━━━━━━━━━━━
┇   *「 Tenki no Ko 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/jurgn2bn007u
┃          Kualitas 720
┃ ~ https://uptobox.com/3hdjd56gy2g2
┃          Kualitas 1080
┃ ~ https://uptobox.com/mq15rgxabmzl
┣ ┅ ━━━━━━━━━━━
┇   *「 Byousoku 5 Centimeter 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/ba2uumhzhx1j
┃          Kualitas 720
┃ ~ https://uptobox.com/ibodg1k2g5z6
┃          Kualitas 1080
┃ ~ https://uptobox.com/f3m60u07mb5k
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┇   *「 Kimi no Suizou wo Tabetai 」*
┣ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
┃          Kualitas 480
┃ ~ https://mega.nz/file/1QozTaiT#DQ7rNo8WAE5ouWcUG3QBp67LizfcYuRy2QfQ_b4W33E
┃          Kualitas 720
┃ ~ https://mega.nz/#!0A13iYpK!TZsGzvWzf6HRzX8pDQkvg6vHOTvqOaFOxG5I8-pKWjU
┃          Kualitas 1080
┃ ~ https://mega.nz/#!UUkjyaKY!sHrTiuMZG9xWSdjNQTXbi_JqdLaSTqg6jFVvwXpw-18
┣ ┅ ━━━━━━━━━━━
┇   *「 Josee to Tora to Sakana-Tachi 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/in1qafje5a99
┃          Kualitas 720
┃ ~ https://uptobox.com/e6j4srt0t8u6
┃          Kualitas 1080
┃ ~ https://uptobox.com/9ft1siwqimvg
┣ ┅ ━━━━━━━━━━━
┇   *「 Kotonoha no Niwa 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/3ut11uq8gxww
┃          Kualitas 720
┃ ~ https://uptobox.com/8sa2w7hsgfu3
┣ ┅ ━━━━━━━━━━━
┇   *「 Hotarubi no Mori e 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/k23nsxopex85
┃          Kualitas 720
┃ ~ https://uptobox.com/pp7pf3gl7lis
┣ ┅ ━━━━━━━━━━━
┇   *「 Kyoukai no Kanata : I'll be Here 」*
┣ ┅ ━━━━━━━━━━━
┃          Kualitas 480
┃ ~ https://uptobox.com/ep9s486r4rdp
┃          Kualitas 720
┃ ~ https://uptobox.com/mf4jjfvredfn
┗ ┅ ━━━━━━━━━━━━━━━━━━━━ ┅ ━
`.trim()
  conn.fakeReply(m.chat, teks, '0@s.whatsapp.net', 'Recommend Anime Movie', 'status@broadcast')
  }
handler.command = /^anmovie$/i
handler.register = true
handler.group = false
handler.private = false
handler.limit = true

module.exports = handler
