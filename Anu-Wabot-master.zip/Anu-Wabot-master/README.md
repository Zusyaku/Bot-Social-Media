## Zbin-Wabot 2.5.4

More compatible, efficient, and simple.
Using advance method to make this sc bot easy to use!

## Multi Device Zbin-Wabot 1.0.0

[`Click Here`](https://www.github.com/Zobin33/Anu-Wabot/tree/multi-device)

# Installation

## Termux
```cmd
$ pkg update && pkg upgrade
$ pkg i git
$ git clone https://github.com/Zobin33/Anu-Wabot
$ cd Anu-Wabot
$ bash install.sh

Scan QR
```

## Manual Install (Termux)
```cmd
$ pkg update && pkg upgrade
$ pkg i git nodejs-lts libwebp ffmpeg
$ git clone https://github.com/Zobin33/Anu-Wabot
$ cd Zbin-Wabot
$ npm i -g
```

## Windows
* [`Download ffmpeg`](https://ffmpeg.org/download.html#build-windows) and set path
* [`Download Node JS`](https://nodejs.org/en/download/)
* [`Download Git`](https://git-scm.com/downloads)
```cmd
> git clone https://github.com/Zobin33/Anu-Wabot
> cd Zbin-Wabot
> npm i -g
```
## Warning!
Do Not Using Nodejs 16 or up And Do Not Using Nodejs 13 or down, Use Nodejs 14!

# Run Bot
```cmd
$ cd Anu-Wabot
$ node index.js
```

# Yang Perlu Di Edit
 
./src/botInfo.json

Jika Ingin Ada Qr Baru session: null 

## Thanks To

* Allah | God
* Nabi Muhammad Saw
* Keluarga
* [`Adiwajshing`](https://github.com/adiwajshing/Baileys)
* [`Rrull`](https://github.com/arl03)
* [`Dt`](https://github.com/Dete4)
* [`VEXG`](https://github.com/VEXG)
* [`Manurios`](http://wa.me/50377257600)
* [`Lindow Amamiya`](https://github.com/mccnlight) 
* [`Loli Protector`](https://github.com/Arya-was) 
* [`Anu Team`](https://chat.whatsapp.com/JMGFxm0SSEF9Ajm0MWJtzh) 


