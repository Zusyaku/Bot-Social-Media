#!/usr/bin/bash
apt-get update && apt-get upgrade
apt-get install git libwebp ffmpeg nodejs
npm install -g 
echo "Instalation Complete, Donate Lah Bang:v"