global.APIs = {
  bx: 'https://bx-hunter.herokuapp.com',
  dhnjing: 'https://dhnjing.xyz',
  kotzyy: 'https://api.kotzyy.xyz',
  hardianto: 'https://hardianto-chan.herokuapp.com',
  jonaz: 'https://jonaz-api-v2.herokuapp.com',
  neoxr: 'https://neoxr-api.herokuapp.com',
  nrtm: 'https://nurutomo.herokuapp.com',
  pencarikode: 'https://pencarikode.xyz',
  xteam: 'https://api.xteam.xyz',
  zahir: 'https://zahirr-web.herokuapp.com',
  zekais: 'http://zekais-api.herokuapp.com',
  zeks: 'https://api.zeks.xyz',
  DashBot: 'https://api.lolhuman.xyz', 
}

global.APIKeys = {
  'https://api.kotzyy.xyz': 'KotzKey',
  'https://bx-hunter.herokuapp.com': 'Ikyy69',
  'https://hardianto-chan.herokuapp.com': 'hardianto',
  'https://neoxr-api.herokuapp.com': 'yntkts',
  'https://pencarikode.xyz': 'pais',
  'https://api.xteam.xyz': 'apikeymu',
  'https://zahirr-web.herokuapp.com': 'zahirgans',
  'https://api.zeks.xyz': 'apivinz',
  'https://api.lolhuman.xyz': 'DashBot',
}

module.exports = { APIs, APIKeys } 

module.exports.userbot = userbot = {
 owner:  [ "6281261324817", "436505555868686", "6285934360746", "62895622934562" ],
   mess: {
   wait: "tunggu sedang di proses...",
   api: "Maaf terjadi kesalahan", 
   success: "Berhasil",
   SudahAktif: "Perintah Tersebut Sudah Diaktifkan Sebelumnya.",
   SudahNonaktif: "Perintah Tersebut Sudah Dinonaktifkan Sebelumnya.",
   KhususGrup: "Perintah ini hanya bisa digunakan di Grup",
   KhususPribadi: "Perintah ini hanya bisa digunakan di private message",
   GrupAdmin: "Perintah ini hanya bisa digunakan oleh Admin Grup",
   BotAdmin: "Bot Harus menjadi admin",
   FreeAdmin: "Admin Bebas",
   KhususOwner: "Perintah ini hanya dapat digunakan oleh owner bot",
   KhususPremium: "Perintah ini khusus member premium"
   },
   error: {
   Iv: "Link yang kamu berikan tidak valid",
   tombol: "Silahkam Masukkan prameter on/off",
   forget: "Silahkan Masukkan Teks Anda."
   },
   setting: {
   butmag: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQObSutCYk40N8IUplw7X65jUTEg7yCs4m49z_4ZXJu1EEbe1tESw5pVPX_&s=10",
   packname: "Stream-BOT",
   author: "Arifi Razzaq",
   prefix: ["/"],
   bio1: "Pejuang Sholawat", 
   bio2: "Road To 30 Juz", 
   gc1: "https://chat.whatsapp.com/C7Vg3OigpIr1oEdbY43E4b", 
 }
   }
