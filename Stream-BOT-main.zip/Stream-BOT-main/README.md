# stream-bot
# Deploy To Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Arifirazzaq2001/Stream-BOT)
# 📦 BuildPack
* [`ffmpeg`](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest)
* [`imagemagick`](https://github.com/rocketmobile/heroku-buildpack-imagemagick)
* [`puppeteer`](https://github.com/jontewks/puppeteer-heroku-buildpack)
