## PINDAH KE LINK BAWAH

https://github.com/Rizxyu/Bot-Rain/tree/main

## Join Group Bot
[![Group Bot](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/CkNED9yeZf82XnVMzRMVRU)
