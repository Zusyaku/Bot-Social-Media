<div align="center">
<img src="https://telegra.ph/file/a264e9f196af02c432417.jpg" alt="XFazd-Team" width="300" />
</div>

# XFazd-Bot🤖

<p align="center">
  <a href="https://github.com/Xfazd-team"><img title="Author" src="https://img.shields.io/badge/Author-XFazd Team-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">

Anda Bisa  Langsung Install Dengan Cara Klik 
Deploy Di Bawah 👇 

##### Deploy To Railway
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/Xfazd-team/XFazd-bot)

##### Deploy To Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Xfazd-team/XFazd-bot)

_________________________

## Termux Install
```bash
> $ pkg install nodejs git ffmpeg libwebp

> $ git clone https://github.com/Xfazd-team/XFazd-bot

> $ cd XFazd-bot

> $ npm i

> $ node main.js
```

## Windows/Rdp/Vps Install
```bash
> $ git clone https://github.com/Xfazd-team/XFazd-bot

> $ cd XFazd-bot

> $ npm i

> $ node main.js
```

## Setting Bot
```bash
{
	"sesionName": "fazd", <- Nama session Anda
	"botName": "Fazd-bot", <- Nama Bot Anda
	"antiDelete": true,
	"autoRead": true,
	"antiSpam": true,
	"pathImg": "./media/Fazd.jpg", <- Image anda
	"ArdyKey": "YourApikey", <- Your apikey buy to ardyapi
        "imgUrl": "https://i.ibb.co/fkqy1XK/Fazd.jpg" <- Image to url anda
}
```
- Setting edit to [this section](https://github.com/Xfazd-team/XFazd-bot/blob/main/setting.json)

## Bot Uji coba di bawah
* [Fazd-Bot](https://wa.me/message/ZOVLFZKWHN7HF1)

# INSTALL
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/ffmpeg-n4.4.1-2-gcc33e73618-win64-gpl-4.4.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)


## Special Thanks To❤️
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`XFazd-Team`](https://github.com/Xfazd-team)
* [`Depin`](https://github.com/finxdev) `Manusia Tak Berotak`
* [`Ardy`](https://github.com/ArdyBotzz)
* [`Reza Dinata`](https://github.com/Dinataaa) `Ohayo Wibu`
* [`Fax Botz`](https://github.com/Faxbotz)
* [`ArifiRazzaq`](https://Github.com/Arifirazzaq2001) `Meng Lord`

