let emote = `•`
module.exports.menu = (prefix, botName) => {
  gjls = 1
  return `Menu *_${botName}_*
  
*Info Menu*
*${gjls++}* ${emote} ${prefix}owner
*${gjls++}* ${emote} ${prefix}runtime
*${gjls++}* ${emote} ${prefix}sc
*${gjls++}* ${emote} ${prefix}q

*Islam Menu*
*${gjls++}* ${emote} ${prefix}kitabkuning

*Hack Menu*
*${gjls++}* ${emote} ${prefix}ssweb _url_

*Maker Menu*
*${gjls++}* ${emote} ${prefix}tahta _teks_

*Game Menu*
*${gjls++}* ${emote} ${prefix}ttc _@tag_
*${gjls++}* ${emote} ${prefix}delttc

*Photooxy*
*${gjls++}* ${emote} ${prefix}glitch _teks1|teks2_
*${gjls++}* ${emote} ${prefix}naruto _teks_
*${gjls++}* ${emote} ${prefix}shadow _teks_
*${gjls++}* ${emote} ${prefix}romantic _teks_
*${gjls++}* ${emote} ${prefix}burnpaper _teks_
*${gjls++}* ${emote} ${prefix}smoke _teks_
*${gjls++}* ${emote} ${prefix}lovemsg _teks_
*${gjls++}* ${emote} ${prefix}doubleheart _teks_
*${gjls++}* ${emote} ${prefix}msggrass _teks_
*${gjls++}* ${emote} ${prefix}coffecup _teks_
*${gjls++}* ${emote} ${prefix}lovetext _teks_
*${gjls++}* ${emote} ${prefix}butterfly _teks_

*Convert*
*${gjls++}* ${emote} ${prefix}stiker
*${gjls++}* ${emote} ${prefix}swm
*${gjls++}* ${emote} ${prefix}dogestick
*${gjls++}* ${emote} ${prefix}patrickstick
*${gjls++}* ${emote} ${prefix}toimg

*Group Menu*
*${gjls++}* ${emote} ${prefix}antilink [on/off]
*${gjls++}* ${emote} ${prefix}welcome [on/off]

*Kerang Menu*
*${gjls++}* ${emote} ${prefix}bisakah
*${gjls++}* ${emote} ${prefix}apakah
*${gjls++}* ${emote} ${prefix}rate
*${gjls++}* ${emote} ${prefix}cekbapak

_*Anonymous chat*_
*${gjls++}* ${emote} ${prefix}anonymous
*${gjls++}* ${emote} ${prefix}start
*${gjls++}* ${emote} ${prefix}next
*${gjls++}* ${emote} ${prefix}leave

_*Sticker Cmd*_
*${gjls++}* ${emote} ${prefix}setcmd [reply]
*${gjls++}* ${emote} ${prefix}delcmd [reply]
*${gjls++}* ${emote} ${prefix}listcmd

*Owner Menu*
*${gjls++}* ${emote} ${prefix}setprefix
*${gjls++}* ${emote} ${prefix}mode self/public
*${gjls++}* ${emote} ${prefix}autoread [on/off]
*${gjls++}* ${emote} ${prefix}antidelete [on/off]
*${gjls++}* ${emote} ${prefix}antispam [on/off]

*Downloader*
*${gjls++}* ${emote} ${prefix}tiktok link
*${gjls++}* ${emote} ${prefix}tiktoknowm link

Power By *Fazd-Bot*
`
}
