const userbot = {
 owner:  [ "6281261324817", "6289677040051" ],
   mess: {
   wait: "tunggu sedang di proses...",
   api: "Maaf terjadi kesalahan", 
   banned: "Maaf Kamu Di Banned Dalam Database Bot Whatsapp",
   success: "Berhasil",
   aktif: "Berhasil, Mengaktifkan Fitur Tersebut", 
   nonaktif: "Berhasil, Menonaktifkan Fitur Tersebut", 
   SudahAktif: "Perintah Tersebut Sudah Diaktifkan Sebelumnya.",
   SudahNonaktif: "Perintah Tersebut Sudah Dinonaktifkan Sebelumnya.",
   KhususGrup: "Perintah ini hanya bisa digunakan di Grup",
   KhususPribadi: "Perintah ini hanya bisa digunakan di private message",
   GrupAdmin: "Perintah ini hanya bisa digunakan oleh Admin Grup",
   BotAdmin: "Bot Harus menjadi admin",
   FreeAdmin: "Admin Bebas",
   NaN: "harus berupa angka", 
   KhususOwner: "Perintah ini hanya dapat digunakan oleh owner bot",
   KhususPremium: "Perintah ini khusus member premium"
   },
   error: {
   tombol: "Silahkam Masukkan prameter on/off",
   forget: "Prameter Salah, Silahkan Masukkan Teks Anda",
   forgetUrl: "Format Salah / Url Tidak Terdeteksi"
   },
   topup: {
   apikey: "",
   nama_store: "Arifi Razzaq Store"
   }, 
   rate_harga: {
      rate_voucher_game: 2
   },
   payment_deposit: {
      gopay_name: "Arifi Razzaq",
      gopay_no: "081261324817",
      dana_name: "Arifi Razzaq",
      dana_no: "081261324817",
      shopee_name: "Arifi Razzaq",
      shopee_no: "081261324817",
      rekening_name: "ARIFI RAZZAQ",
      rekening_no: "5320-01-018862-53-6"
   }, 
   setting: {
   packname: "Di Buat Oleh: Arifi Razzaq OFFICIAL",
   author: "Arifi Razzaq",
   botname: "SCRAPE-BOT",
   prefix: ["/"],
   noprefix: [""],
   sessionName: "Qrcode",
   gamewaktu: 70,
   limitCount: 10, 
   limitCountb: 3
   }, 
   source: {
   urlLinkYt_replyText: "https://youtu.be/wxhgJShehY4"
   },
   gcount: {
   prem: 100,
   user: 10
   }
}

  module.exports = { 
  userbot
}