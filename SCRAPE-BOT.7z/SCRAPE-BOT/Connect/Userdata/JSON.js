"use strict";
global.pengunjung = JSON.parse(global.Ft['fs'].readFileSync('./Database/pengunjung.json'));