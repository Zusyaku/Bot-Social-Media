<div align="center">
<img src="https://github.com/Paiiss/Pais/blob/main/Fummy.jpg?raw=true" alt="FummyBOT"width="240" height="260" />
<p align="center">
  <a href="https://github.com/Paiiss"><img title="Author" src="https://img.shields.io/badge/Author-Paiiss-purple.svg?style=for-the-badge&logo=github" /></a>
</p>
<p align="center">
<a href="https://github.com/Paiiss/"><img title="Followers" src="https://img.shields.io/github/followers/Paiiss?color=blue&style=flat-square"></a>
<a href="https://github.com/Paiiss/"><img title="Stars" src="https://img.shields.io/github/stars/Paiiss/FummyBOT?color=red&style=flat-square"></a>
<a href="https://github.com/Paiiss/"><img title="Forks" src="https://img.shields.io/github/forks/Paiiss/FummyBOT?color=red&style=flat-square"></a>
<a href="https://github.com/Paiiss/"><img title="Watching" src="https://img.shields.io/github/watchers/Paiiss/FummyBOT?label=Watchers&color=blue&style=flat-square"></a>
</p>


</div>

## Information

## This script is free / open to anyone! If you want to add orders, please contribute / withdraw requests! Buying and selling scripts is prohibited!

# Features

|      Downloader     | Availability |
| :-----------------: | :----------: |
|   Tiktok Wm         |      ✔️      |
|   Tiktok No Wm      |      ✔️      |
|   Youtube Mp3       |      ✔️      |
|   Youtube Video     |      ✔️      |
|   Youtube Search    |      ✔️      |
|   Xnxx Download     |      ✔️      |
|   Instagram Post    |      ✔️      |


|        Music        | Availability |
| :-----------------: | :----------: |
|       Joox          |      ✔️      |
|      Joox Plus      |      ✔️      |
|        Play         |      ✔️      |
|        Lyric        |      ✔️      |

|       Education     | Availability |
| :-----------------: | :----------: |
|       Merdeka       |      ✔️      |
|        Corona       |      ✔️      |
|       Coronaind     |      ✔️      |
|        Gempa        |      ✔️      |
|      Wikipedia      |      ✔️      |
|      pinterest      |      ✔️      |

|         Other       | Availability |
| :-----------------: | :----------: |
|       Truth Id      |      ✔️      |
|        Nulis        |      ✔️      |
|       Nick Ml       |      ✔️      |
|       Short Url     |      ✔️      |
|         Spam1       |      ✔️      |
|       Arti Nama     |      ✔️      |
|          Etc        |      ++      |


## How to get a bot token
* Open telegram and search for @BotFather
* Type / newbot
* Follow all the instructions given, and copy the token into the token column in ```setting.json```


## ✍️ Editing the file
Edit the required value in `config.json`.
```json
{
    "Token": "Token lu asw",
    "paisKey": "Fummy",
    "lolKey": "Apikey",
    "vhKey": "Apikey",
    "prefix": "/",
    "ownerbot": "Pais"
}

```

## Apikey
* [Pais](https://pencarikode.xyz/)
* [LolHuman](http://lolhuman.herokuapp.com/)
* [VhTear](https://api.vhtear.com/)

# Requirements
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* Intention
* Any text editor

# Installation

## Cloning this repo
```cmd
> git clone https://github.com/Paiiss/FummyBOT.git
> cd FummyBOT
```

## Install the package
```cmd
> npm i
```

## Run the bot
```cmd
> npm start
```
# The bot is already running on your token that you entered

## Note:
* You can use node / nodemon, you can set the settings in ```package.json``` and house nodemon to be a node

# Thanks To
* [`Telegraf`](https://www.npmjs.com/package/telegraf)
* [`LolHuman`](https://github.com/LoL-Human/)
* [`Puh dhil`](https://github.com/Dhil-J)
* [`vhtear`](https://github.com/fckveza/)
* [`Aldi`](https://github.com/Alphanum404)
* Ben

# Read docs
* [`Telegraf`](https://telegraf.js.org/v3#/)
